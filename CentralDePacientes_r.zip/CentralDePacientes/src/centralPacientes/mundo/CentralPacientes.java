package centralPacientes.mundo;

import java.util.ArrayList;


public class CentralPacientes {
    
    private ArrayList<Paciente> pacientes;

    private ArrayList<String> listaClinicas;

    public CentralPacientes() {
        pacientes = new ArrayList<>();

        listaClinicas = new ArrayList<>();
        listaClinicas.add("Clínica del Country");
        listaClinicas.add("Clínica Palermo");
        listaClinicas.add("Clínica Reina Sofía");
        listaClinicas.add("Clínica El Bosque");
        listaClinicas.add("Clínica San Ignacio");
        listaClinicas.add("Otra");
    }

  

   
    public int darNumeroPacientes() {
        return pacientes.size();
    }

    
    public void agregarPacienteAlComienzo(Paciente pac) {
        pacientes.add(0, pac); 
    }

    /
    public void agregarPacienteAlFinal(Paciente pac) {
        pacientes.add(pac); 
    }

    public void agregarPacienteAntesDe(int cod, Paciente pac) throws NoExisteException {
        int index = -1;
        for (int i = 0; i < pacientes.size(); i++) {
            if (pacientes.get(i).getCodigo() == cod) {
                index = i;
                break;
            }
        }
        if (index != -1) {
            pacientes.add(index, pac); 
        } else {
            throw new NoExisteException("No existe un paciente con el código dado");
        }
    }

    
    public void agregarPacienteDespuesDe(int cod, Paciente pac) throws NoExisteException {
        int index = -1;
        for (int i = 0; i < pacientes.size(); i++) {
            if (pacientes.get(i).getCodigo() == cod) {
                index = i;
                break;
            }
        }
        if (index != -1) {
            pacientes.add(index + 1, pac); 
        } else {
            throw new NoExisteException("No existe un paciente con el código dado");
        }
    }

    
    public Paciente localizar(int codigo) {
        for (Paciente paciente : pacientes) {
            if (paciente.getCodigo() == codigo) {
                return paciente;
            }
        }
        return null; 
    }

    
    public void eliminarPaciente(int cod) throws NoExisteException {
        Paciente pacienteAEliminar = localizar(cod);
        if (pacienteAEliminar != null) {
            pacientes.remove(pacienteAEliminar); 
        } else {
            throw new NoExisteException("No existe un paciente con el código dado");
        }
    }

    
    public ArrayList<Paciente> darPacientes() {
        return pacientes;
    }

    
    public ArrayList<String> darListaClinicas() {
        return listaClinicas;
    }

    
    private int darLongitud() {
        return pacientes.size();
    }

     int cantHombres() {
        int contador = 0;
        for (Paciente paciente : pacientes) {
            if (paciente.getGenero().equalsIgnoreCase("masculino")) {
                contador++;
            }
        }
        return contador;
    }

    
    public int cantMujeres() {
        int contador = 0;
        for (Paciente paciente : pacientes) {
            if (paciente.getGenero().equalsIgnoreCase("femenino")) {
                contador++;
            }
        }
        return contador;
    }

    
    public String metodo4() {
        int[] conteoPacientes = new int[listaClinicas.size()];

        for (Paciente paciente : pacientes) {
            String clinicaPaciente = paciente.getClinica();
            int index = listaClinicas.indexOf(clinicaPaciente);
            if (index != -1) {
                conteoPacientes[index]++;
            }
        }

        int maxPacientes = 0;
        int indexMax = -1;

        for (int i = 0; i < conteoPacientes.length; i++) {
            if (conteoPacientes[i] > maxPacientes) {
                maxPacientes = conteoPacientes[i];
                indexMax = i;
            }
        }

        return listaClinicas.get(indexMax);
    }
}
