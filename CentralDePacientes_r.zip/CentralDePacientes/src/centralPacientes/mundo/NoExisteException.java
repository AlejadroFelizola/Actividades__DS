package centralPacientes.mundo;

public class NoExisteException extends Exception {
   
    public NoExisteException(int codigo) {
        super("El paciente con código " + codigo + " no está registrado");
    }

   
    public NoExisteException(String mensaje) {
        super(mensaje);
    }
}
