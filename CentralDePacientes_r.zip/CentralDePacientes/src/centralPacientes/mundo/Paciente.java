package centralPacientes.mundo;

public class Paciente {
   
    public final static int HOMBRE = 1;

    public final static int MUJER = 2;

    private int codigo;

    private String nombre;

    private String clinica;

    private String informacionMedica;

    private int sexo;

    public Paciente(int cod, String nom, String clin, String infoMed, int sex) {
        codigo = cod;
        nombre = nom;
        clinica = clin;
        informacionMedica = infoMed;
        sexo = sex;
    }

    public int darCodigo() {
        return codigo;
    }

    public String darNombre() {
        return nombre;
    }

    public String darClinica() {
        return clinica;
    }

    public String darInformacionMedica() {
        return informacionMedica;
    }

    
    public int darSexo() {
        return sexo;
    }

    
    public String toString() {
        return "[ " + codigo + " ]: " + nombre;
    }

    
    public void cambiarInformacionMedica(String informacion) {
        informacionMedica = informacion;
    }

    
    public String getGenero() {
        return sexo == HOMBRE ? "Masculino" : "Femenino";
    }
}
