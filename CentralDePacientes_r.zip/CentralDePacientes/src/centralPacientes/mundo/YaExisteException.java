package centralPacientes.mundo;

public class YaExisteException extends Exception {
   
    public YaExisteException(int codigo) {
        super("El paciente con código " + codigo + " ya está registrado");
    }

    
    public YaExisteException(String mensaje) {
        super(mensaje);
    }
}
