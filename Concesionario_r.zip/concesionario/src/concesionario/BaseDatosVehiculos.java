package concesionario;

import java.util.ArrayList;
import java.util.List;

public class BaseDatosVehiculos {
    private List<Vehiculo> vehiculos;

    public BaseDatosVehiculos() {
        this.vehiculos = new ArrayList<>();
        
        
        this.vehiculos.add(new Vehiculo("Automóvil", "Toyota", "Corolla", 2010, 2, 1800, 8000, "ABC123"));
        this.vehiculos.add(new Vehiculo("Moto", "Honda", "CBR", 2015, 0, 600, 5000, "XYZ987"));
        this.vehiculos.add(new Vehiculo("Camión", "Mercedes", "Actros", 2008, 6, 12000, 25000, "JKL456"));
        this.vehiculos.add(new Vehiculo("Bus", "Volvo", "B11R", 2012, 4, 10800, 30000, "MNO789"));
    }

   
    public List<Vehiculo> obtenerVehiculos() {
        return vehiculos;
    }

    
    public Vehiculo obtenerVehiculoPorPlaca(String placa) {
        for (Vehiculo v : vehiculos) {
            if (v.getPlaca().equals(placa)) {
                return v;
            }
        }
        return null; 
    }

    
    public void agregarVehiculo(Vehiculo vehiculo) {
        vehiculos.add(vehiculo);
    }

    
    public boolean eliminarVehiculo(String placa) {
        return vehiculos.removeIf(v -> v.getPlaca().equals(placa));
    }
}
