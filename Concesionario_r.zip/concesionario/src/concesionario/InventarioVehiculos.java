package concesionario;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class InventarioVehiculos {
    private List<Vehiculo> vehiculos;

    public InventarioVehiculos() {
        this.vehiculos = new ArrayList<>();
    }

    
    public List<String> obtenerPlacas() {
        return vehiculos.stream().map(Vehiculo::getPlaca).collect(Collectors.toList());
    }

    
    public Vehiculo obtenerVehiculoPorPlaca(String placa) {
        return vehiculos.stream()
                        .filter(v -> v.getPlaca().equals(placa))
                        .findFirst()
                        .orElse(null);
    }

    
    public void agregarVehiculo(Vehiculo vehiculo) {
        vehiculos.add(vehiculo);
    }

    
    public void ordenarPorModelo() {
        vehiculos.sort(Comparator.comparing(Vehiculo::getModelo));
    }

    public void ordenarPorMarca() {
        vehiculos.sort(Comparator.comparing(Vehiculo::getMarca));
    }

    public void ordenarPorAño() {
        vehiculos.sort(Comparator.comparingInt(Vehiculo::getAño));
    }

    
    public List<String> buscarPorModeloYAño(String modelo, int año) {
        return vehiculos.stream()
                        .filter(v -> v.getModelo().equals(modelo) && v.getAño() == año)
                        .map(Vehiculo::getPlaca)
                        .collect(Collectors.toList());
    }

    
    public void comprarVehiculo(String placa) {
        vehiculos.removeIf(v -> v.getPlaca().equals(placa));
    }

    
    public void reducirPrecio(double cantidad) {
        vehiculos.stream()
                 .filter(v -> v.getValor() > cantidad)
                 .forEach(v -> v.setValor(v.getValor() * 0.9));
    }

    
    public Vehiculo localizarVehiculoMasAntiguo() {
        return vehiculos.stream()
                        .min(Comparator.comparingInt(Vehiculo::getAño))
                        .orElse(null);
    }

    
    public Vehiculo localizarVehiculoMasPotente() {
        return vehiculos.stream()
                        .max(Comparator.comparingInt(Vehiculo::getCilindrada))
                        .orElse(null);
    }

    
    public Vehiculo localizarVehiculoMasBarato() {
        return vehiculos.stream()
                        .min(Comparator.comparingDouble(Vehiculo::getValor))
                        .orElse(null);
    }
}
