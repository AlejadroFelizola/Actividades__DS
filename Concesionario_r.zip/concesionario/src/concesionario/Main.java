package concesionario;

public class Main {
    public static void main(String[] args) {
        InventarioVehiculos inventario = new InventarioVehiculos();

       
        inventario.agregarVehiculo(new Vehiculo("Automóvil", "Toyota", "Corolla", 2010, 2, 1800, 8000, "ABC123"));
        inventario.agregarVehiculo(new Vehiculo("Moto", "Honda", "CBR", 2015, 0, 600, 5000, "XYZ987"));
        inventario.agregarVehiculo(new Vehiculo("Camión", "Mercedes", "Actros", 2008, 6, 12000, 25000, "JKL456"));

        
        System.out.println("Placas: " + inventario.obtenerPlacas());

        
        System.out.println("Vehículo ABC123: " + inventario.obtenerVehiculoPorPlaca("ABC123"));

    
        inventario.ordenarPorAño();
        System.out.println("Vehículos ordenados por año: ");
        inventario.obtenerPlacas().forEach(System.out::println);

        
        inventario.reducirPrecio(6000);
        System.out.println("Vehículo más barato: " + inventario.localizarVehiculoMasBarato());
    }
}
