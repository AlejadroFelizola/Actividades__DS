package concesionario;

public class Vehiculo {
    private String tipo;
    private String marca;
    private String modelo;
    private int año;
    private int ejes;
    private int cilindrada;
    private double valor;
    private String placa;

    public Vehiculo(String tipo, String marca, String modelo, int año, int ejes, int cilindrada, double valor, String placa) {
        this.tipo = tipo;
        this.marca = marca;
        this.modelo = modelo;
        this.año = año;
        this.ejes = ejes;
        this.cilindrada = cilindrada;
        this.valor = valor;
        this.placa = placa;
    }

    public String getPlaca() {
        return placa;
    }

    public String getModelo() {
        return modelo;
    }

    public String getMarca() {
        return marca;
    }

    public int getAño() {
        return año;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public int getCilindrada() {
        return cilindrada;
    }

    @Override
    public String toString() {
        return "Tipo: " + tipo + ", Marca: " + marca + ", Modelo: " + modelo + 
               ", Año: " + año + ", Ejes: " + ejes + ", Cilindrada: " + cilindrada + 
               ", Valor: " + valor + ", Placa: " + placa;
    }
}

